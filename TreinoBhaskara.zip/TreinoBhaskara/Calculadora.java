import javax.swing.JOptionPane;

public class Calculadora {

    public static void main(String[] args) {

        int tentarNovamente; 
        
        do {
            // 1. Entrada de dados
            double a = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de A: "));
            double b = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de B: "));
            double c = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de C: "));
            
            // 2. Instanciação: Criando o objeto da classe Equacao (com "E" maiúsculo)
            Equacao equacao = new Equacao(a, b, c);
            
            // 3. Processamento: Pedindo para o objeto gerar o relatório
            String mensagemFinal = equacao.gerarRelatorio();

            // 4. Exibição do Resultado
            JOptionPane.showMessageDialog(null, "O resultado da equação é:\n" + mensagemFinal);
            
            tentarNovamente = JOptionPane.showConfirmDialog(null, 
                        "Deseja calcular outra equação?", 
                        "Continuar?", 
                        JOptionPane.YES_NO_OPTION);
            
        } while (tentarNovamente == JOptionPane.YES_OPTION);
        
        JOptionPane.showMessageDialog(null, "Programa encerrado. Até a próxima!");
    }
}
