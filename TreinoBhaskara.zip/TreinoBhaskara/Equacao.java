public class Equacao {
    
    // 1. Atributos: O estado da nossa equação (os valores de a, b e c)
    private double a;
    private double b;
    private double c;

    // 2. Construtor: O método que a Calculadora usa para passar os números pra cá
    public Equacao(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // 3. Métodos: Os comportamentos (a matemática em si)
    
    // Método para calcular o delta
    public double calcularDelta() {
        return (this.b * this.b) - (4 * this.a * this.c);
    }

    // Método para calcular a primeira raiz (x1)
    public double calcularRaiz1() {
        return (-this.b + Math.sqrt(calcularDelta())) / (2 * this.a);
    }

    // Método para calcular a segunda raiz (x2)
    public double calcularRaiz2() {
        return (-this.b - Math.sqrt(calcularDelta())) / (2 * this.a);
    }

    // Método que junta os resultados e devolve o texto pronto para a Calculadora exibir
    public String gerarRelatorio() {
        double delta = calcularDelta();
        
        if (delta < 0) {
            return "Delta é " + delta + ". Portanto, não existem raízes reais.";
        } else if (delta == 0) {
            return "Delta é zero. Existe apenas uma raiz real:\nx = " + calcularRaiz1();
        } else {
            return "Delta é " + delta + ". Temos duas raízes:\nx1 = " + calcularRaiz1() + "\nx2 = " + calcularRaiz2();
        }
    }
}